<?php
/*
Plugin Name: Synaptica Importer
Plugin URI: 
Description: Import terms from Synaptica into your WordPress taxonomies.
Author: Russell Heimlich
Author URI: http://www.russellheimlich.org/blog
Version: 0.2
Stable tag: 0.2
License: GPL v2 - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

if ( !defined('WP_LOAD_IMPORTERS') )
	return;

// Load Importer API
require_once ABSPATH . 'wp-admin/includes/import.php';

if ( !class_exists( 'WP_Importer' ) ) {
	$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
	if ( file_exists( $class_wp_importer ) )
		require_once $class_wp_importer;
}

/**
 * Synaptica Importer
 *
 * @package WordPress
 * @subpackage Importer
 */
if ( class_exists( 'WP_Importer' ) ) {
class Synaptica_Import extends WP_Importer {
	
	var $file;
	var $xml;
	var $id;
	var $selected_taxonomy;
	var $selected_site_ids;
	var $site_details;
	var $global_termID;

	function header() {
		echo '<div class="wrap">';
		screen_icon();
		echo '<h2>'.__('Import Synaptica2', 'synaptica-importer2').'</h2>';
	}

	function footer() {
		echo '</div>';
	}

	function greet() {
		echo '<div class="narrow">';
		echo '<p>'.__('Howdy! Upload your Synaptica XML file and we&#8217;ll import the terms into this site\'s taxonomies.', 'synaptica-importer2').'</p>';
		echo '<p>'.__('Choose a Synaptica XML file to upload, which sites this file applies to, the taxonomy to be modified, and then click the Upload file and import button.', 'synaptica-importer2').'</p>';
		
		
		echo '<form action="?import=synaptica&amp;step=1&amp;_wpnonce=' . wp_create_nonce('import-upload') . '" method="post" id="import-upload-form" enctype="multipart/form-data">';
		//wp_nonce_field('import-upload');	
		
		$user_id = get_current_user_id();
		$user_sites = get_blogs_of_user( $user_id );
		foreach ($user_sites AS $user_site) {
			$site_path = preg_replace('/\//i', '', $user_site->path); //Strip slashes in user-path
			if($user_site->path == '/') { $site_path = 'blog'; }
			?>
			<input name="<?=$site_path?>" id="<?=$site_path?>" type="checkbox" value="<?=$user_site->userblog_id?>"> <label for="<?=$site_path?>"><?=$user_site->blogname?></label><br>
		<?php
		}
		?>
        <p><select name="taxonomy">
        	<option selected>Select a taxonomy</option>
        <?php
		foreach(get_taxonomies() as $taxonomy) {
			$taxonomy = get_taxonomy($taxonomy);
			if(!$taxonomy->_builtin) { //Filter out the default taxonomies.
			?>
            <option value="<?=$taxonomy->name;?>"><?=$taxonomy->labels->name;?></option>
			<?php
			}
		}
		?>
        </select></p>
        <p>
			<label for="upload">Choose a file from your computer:</label> (Maximum size: 0)
			<input type="file" size="25" name="import" id="upload">
			<input type="hidden" value="save" name="action">
			<input type="hidden" value="0" name="max_file_size">
		</p>
		<?php				
		echo '<p class="submit">';
		echo '<input type="submit" class="button" value="'. esc_attr__('Upload file and import', 'synaptica-importer2') .'" />'.'<br />';
		echo '</p>';
		echo '</form>';
		
		echo '</div>';
	}
	
	
	
	
	
	function term_creation_callback($term_id, $tt_id) {
		$new_term_id = (int) $this->global_termID;
		(int) $term_id;
		global $wpdb;
		$wpdb->query("UPDATE $wpdb->terms SET term_id = " . $new_term_id . " WHERE term_id = " . $term_id);
		$wpdb->query("UPDATE $wpdb->term_taxonomy SET term_id = " . $new_term_id . " WHERE term_id = " . $term_id);
		
		clean_term_cache($new_term_id, $tt_id, true);
	}
	
	function buildParent($parent, $parentID) {
		foreach ($parent->term as $term) {
			$result = $this->buildChild($term, $parentID);
    	}
    	return $result;
	}

	function buildChild($term, $parentID) {
    	$termName = (string) $term->termName;
		$termID = (int) $term->termId;
		$taxonomy = $this->selected_taxonomy;
		$this->global_termID = $termID;
		
		//if (isset($term->relation)) {
        	//$parentID = $term->relation->termId;
    	//}
		
		$args = array(
			'name'=>$termName,
			'parent'=>(int) $parentID
		);
		if(get_term($termID, $taxonomy)) {
			$result = wp_update_term( $termID, $taxonomy, $args);
			$status = ' updated in the ';
		}
		else {
			add_action('create_term', array(&$this, 'term_creation_callback'), 1, 2);
			$result = wp_insert_term($termName, $taxonomy, $args);
			$status = ' <strong>added</strong> to the ';
		}
		echo '<li><a target ="_blank" href="' . $this->site_details->siteurl . '/wp-admin/edit-tags.php?action=edit&taxonomy=' . $this->selected_taxonomy . '&tag_ID=' . $termID . '">' . $termName . '</a>' . $status . '<em>' . $taxonomy .'</em> taxonomy</li>';
	}
	
	function process_terms($site_id) {
		switch_to_blog( $site_id );
		if( !taxonomy_exists( $this->selected_taxonomy ) ) {
			return new WP_Error('invalid-taxonomy', 'The ' . $this->selected_taxonomy . ' taxonomy doesn\'t exist in ' . $this->site_details->blogname);
		}
		$this->site_details = get_blog_details($site_id);
		echo '<h3><a target ="_blank" href="' . $this->site_details->siteurl . '/wp-admin/edit-tags.php?taxonomy=' . $this->selected_taxonomy . '">' . $this->site_details->blogname . '</a></h3>';
		echo '<ol>';
		$this->buildParent($this->xml, 0);
		echo '</ol>';
		echo '<p>&nbsp;</p>'; //spacer.gif 2.0!
		return true;
	}

	function max_attachment_size() {
		// can be overridden with a filter - 0 means no limit
		return apply_filters('import_attachment_size_limit', 0);
	}

	function import_start() {
		//$this->xml = simplexml_load_file($this->file);
		$this->xml = simplexml_load_string( get_transient('synaptica-import_xml') );
		wp_defer_term_counting(true);
		wp_defer_comment_counting(true);
		do_action('import_start');
	}

	function import_end() {
		do_action('import_end');
		wp_defer_term_counting(false);
		wp_defer_comment_counting(false);
		clean_object_term_cache(get_taxonomies(), 'post');
		delete_transient($this->id);
	}

	function validate_form_data() {
		if( taxonomy_exists( $_POST['taxonomy'] ) ) {
			$this->selected_taxonomy = $_POST['taxonomy'];
		}
		else {
			echo 'No taxonomy selected!';
			return false;
		}
		$selected_site_ids = &$_POST;
		if( count($selected_site_ids) > 3 ) { //Remove the last three elements from the post array leaving only the site ID's checked in step 0;
			array_splice($selected_site_ids, -3);
			$this->selected_site_ids = $selected_site_ids;
		}
		else {
			echo 'No sites selected!';
			return false;
		}
		return true;
	}
	
	function handle_upload() {
		$file = wp_import_handle_upload();
		if ( isset($file['error']) ) {
			echo '<p>'.__('Sorry, there has been an error.', 'synaptica-importer2').'</p>';
			echo '<p><strong>' . $file['error'] . '</strong></p>';
			return false;
		}
		//$this->id = (int) $file['id'];
		$file_contents = file_get_contents($file['file']);
		set_transient('synaptica-import_xml', $file_contents, 900); //Store the uploaded XML file in a transient that expires in 900 seconds.
		//$this->file = $file['file'];
		return true;
	}

	function dispatch() {
		if (empty ($_GET['step']))
			$step = 0;
		else
			$step = (int) $_GET['step'];

		$this->header();
		switch ($step) {
			case 0 :
				$this->greet();
				break;
			case 1 :
				check_admin_referer('import-upload');
				if ( $this->handle_upload() && $this->validate_form_data() ) {					
					$this->import_start();
					foreach($this->selected_site_ids as $site) {
						$result = $this->process_terms($site);
						if ( is_wp_error( $result ) ) {
							echo $result->get_error_message();
						}
					}
				}
				$this->import_end();
				break;
			case 2:
				//Nothing
		}
		$this->footer();
	}

	function WP_Import() {
		// Nothing.
	}
}

/**
 * Register Synaptica Importer
 *
 * @since unknown
 * @var WP_Import
 * @name $wp_import
 */
$synaptica_import = new Synaptica_Import();

register_importer('synaptica', 'Synaptica', __('Import terms from Synaptica into your WordPress taxonomies.', 'synaptica-importer2'), array ($synaptica_import, 'dispatch'));

} // class_exists( 'WP_Importer' )

function synaptica_importer_init() {
    //load_plugin_textdomain( 'synaptica-importer2', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
//add_action( 'init', 'wordpress_importer_init' );
